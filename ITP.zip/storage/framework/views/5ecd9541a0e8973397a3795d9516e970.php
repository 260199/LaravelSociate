
<?php $__env->startSection('isi'); ?>
<div class="container-fluid">
    <div class="card shadow mb-4">
        <div class="card-header py-3">
            <h6 class="m-0 font-weight-bold text-primary">Log Activity</h6>
        </div>
        <div class="card-body">
            <?php if(session('success')): ?>
            <div class="alert alert-success alert-dismissible fade show" role="alert">
                <?php echo e(session('success')); ?>

                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
              <?php endif; ?>
        
            <button class="btn btn-md btn-success mb-3" data-toggle="modal" data-target="#modalTambahDaily">
                Tambah Daily
            </button>
            <button class="btn btn-danger mb-3" id="openMassReportModal" data-toggle="modal" data-target="#modalSendReport" disabled>
                Send Report
            </button>

            <div class="form-check">
                <input class="form-check-input" type="checkbox" id="checkAllEligible">
                <label class="form-check-label" for="checkAllEligible">
                    Ceklis Semua yang Bisa Dilaporkan
                </label>
            </div>
            <div class="form-group">
                <label for="filterStatus">Status</label>
                <select id="filterStatus" class="form-control">
                    <option value="">-- Pilih Status --</option>
                    <option value="progress">Sedang Proses</option>
                    <option value="dilaporkan">Dilaporkan</option>
                    <option value="diterima">Diterima</option>
                </select>
            </div>
            <div class="table-responsive">
                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0" style="color:black;"> 
                    <thead>
                        <tr style="text-align: center;">
                            <th>#</th>
                            <th>Tgl Dibuat</th>
                            <th>Nama</th>
                            <th>Kegiatan</th>
                            <th>Jenis</th>
                            <th>Bukti</th>
                            <th>Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                            $no=1;
                        ?>
                        <?php $__currentLoopData = $daily; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($no++); ?>

                                    <?php
                                    $buktiUploaded = $item->filedailies->count() > 0;
                                    ?>
                                    
                                    <input type="checkbox" class="daily-checkbox" value="<?php echo e($item->id); ?>" <?php echo e($item->status == 'dilaporkan' || !$buktiUploaded ? 'disabled' : ''); ?>>
                                </td>
                                <td><?php echo e(\Carbon\Carbon::parse($item->created_at)->translatedFormat('d F Y')); ?></td>
                                <td><?php echo e($item->user->name ?? 'N/A'); ?> <br>
                                    <?php if($item->status == 'dilaporkan'): ?>
                                        <span class="badge badge-danger">Waiting Approve</span>
                                    <?php elseif($item->status == 'diterima'): ?>
                                    <span class="badge badge-success">Diterima Admin</span>
                                    <?php else: ?>
                                        <span class="badge badge-warning">Sedang Proses</span>
                                    <?php endif; ?>
                                </td>
                                <td><?php echo e($item->kegiatan); ?></td>
                                <td><?php echo e($item->jenis); ?></td>
                                <td style="text-align: center;">
                                    <?php if($item->status == 'dilaporkan'): ?>
                                        <a href="<?php echo e(route('daily.detail', $item->id)); ?>" class="btn btn-sm btn-info" data-bs-toggle="tooltip" title="Dilaporkan pada: <?php echo e(\Carbon\Carbon::parse($item->done_at)->translatedFormat('d F Y')); ?>"><i class="fas fa-info"></i></a>
                                    <?php elseif($item->status == 'diterima'): ?>
                                    <a href="<?php echo e(route('daily.detail', $item->id)); ?>" class="btn btn-sm btn-info" data-bs-toggle="tooltip" title="Dilaporkan pada: <?php echo e(\Carbon\Carbon::parse($item->done_at)->translatedFormat('d F Y')); ?>"><i class="fas fa-info"></i></a>
                                    <?php elseif($item->filedailies->count() > 0): ?>
                                        <span class="badge badge-primary">Sudah upload kegiatan</span>
                                    <?php else: ?>
                                        -
                                    <?php endif; ?>
                                </td>
                                <td style="text-align: center;">
                                    <div class="d-flex align-items-center">
                                        <?php
                                         $batasWaktu = \Carbon\Carbon::parse($item->created_at)->addDays(3);
                                        ?>
                                        <?php if($item->status != 'dilaporkan' && now()->lessThanOrEqualTo($batasWaktu)): ?>
                                        <button class="btn btn-warning btn-sm" style="margin-left:5px;" data-toggle="modal" data-target="#modalEditDaily<?php echo e($item->id); ?>" title="Edit">
                                            <i class="fas fa-edit"></i>
                                        </button>
                                        <?php elseif($item->status == 'dilaporkan'): ?>
                                        <button class="btn btn-warning btn-sm" style="margin-left:5px;" data-toggle="modal" data-target="#modalEditDaily<?php echo e($item->id); ?>" title="Edit" disabled>
                                            <i class="fas fa-edit"></i>
                                        </button>                                        
                                        <?php endif; ?>
                                    
                                        <form action="<?php echo e(route('daily.destroy', $item->id)); ?>" method="POST" class="d-inline-block" id="deleteForm<?php echo e($item->id); ?>">
                                            <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                                            <button type="button" class="btn btn-danger btn-sm" style="margin-left:5px;" title="Hapus" data-toggle="modal" data-target="#confirmDeleteModal" onclick="setDeleteAction('<?php echo e(route('daily.destroy', $item->id)); ?>')">
                                                <i class="fas fa-trash"></i>
                                            </button>
                                        </form>
                                    
                                        <?php
                                            $batasWaktu = \Carbon\Carbon::parse($item->created_at)->addDays(3);
                                        ?>
                                    
                                        <?php if($item->status != 'dilaporkan' && now()->lessThanOrEqualTo($batasWaktu)): ?>
                                        <?php elseif($item->status != 'dilaporkan'): ?>
                                            <span class="badge badge-secondary">Expired</span>
                                        <?php endif; ?>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
                <?php $__currentLoopData = $daily; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <!-- Modal Edit -->
                <div class="modal fade" id="modalEditDaily<?php echo e($item->id); ?>" tabindex="-1" role="dialog" aria-labelledby="modalEditDailyLabel<?php echo e($item->id); ?>" aria-hidden="true">
                    <div class="modal-dialog modal-dialog-scrollable modal-fullscreen-sm-down" role="document">
                        <form action="<?php echo e(route('daily.update', $item->id)); ?>" method="POST" enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('PUT'); ?>
                            <div class="modal-content">
                                <div class="modal-header">
                                    <h5 class="modal-title" id="modalEditDailyLabel<?php echo e($item->id); ?>">Edit Kegiatan Harian</h5>
                                    <button type="button" class="close" data-dismiss="modal" aria-label="Tutup">
                                        <span aria-hidden="true">&times;</span>
                                    </button>
                                </div>
                                
                                <div class="modal-body">
                                    <div class="mb-3">
                                        <label for="kegiatan<?php echo e($item->id); ?>">Nama Kegiatan</label>
                                        <input type="text" id="kegiatan<?php echo e($item->id); ?>" name="kegiatan" class="form-control" value="<?php echo e($item->kegiatan); ?>" required>
                                    </div>
                                    
                                    <div class="mb-3">
                                        <label for="jenis<?php echo e($item->id); ?>">Jenis Kegiatan</label>
                                        <input type="text" id="jenis<?php echo e($item->id); ?>" name="jenis" class="form-control" value="<?php echo e($item->jenis); ?>" required>
                                    </div>
                                    
                                    <div class="mb-3">
                                        <label for="deskripsi<?php echo e($item->id); ?>">Deskripsi</label>
                                        <textarea id="deskripsi<?php echo e($item->id); ?>" name="deskripsi" class="form-control" rows="3"><?php echo e($item->deskripsi); ?></textarea>
                                    </div>

                                    <?php if($item->filedailies->count()): ?>
                                    <div class="mb-3">
                                        <label><strong>Bukti yang sudah diupload</strong></label><br>
                                        <?php $__currentLoopData = $item->filedailies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $file): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <img
                                                src="<?php echo e(asset('storage/' . $file->image_path)); ?>"
                                                alt="Bukti"
                                                class="img-thumbnail preview-uploaded-img"
                                                data-img="<?php echo e(asset('storage/' . $file->image_path)); ?>"
                                                data-desc="<?php echo e($file->desc ?: 'Tanpa deskripsi'); ?>"
                                                style="max-width: 100%; margin: 5px 0; border:1px solid #ddd; padding:3px; cursor: pointer;">
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </div>
                                    <?php endif; ?>

                                    <?php
                                        $doneAtValue = old('done_at') ?? ($item->done_at ? \Carbon\Carbon::parse($item->done_at)->format('Y-m-d') : '');
                                    ?>

                                    <div class="form-group mt-3">
                                        <label for="done_at">Tanggal diterima</label>
                                        <input type="date" name="done_at" id="done_at" class="form-control"
                                            min="<?php echo e($item->created_at->format('Y-m-d')); ?>"
                                            max="<?php echo e($item->created_at->copy()->addDays(3)->format('Y-m-d')); ?>"
                                            value="<?php echo e($doneAtValue); ?>"
                                            <?php echo e($item->status === 'diterima' ? 'readonly' : ''); ?>>
                                        <small class="text-muted">
                                            Maksimal 3 hari dari tanggal dibuat: <?php echo e($item->created_at->copy()->addDays(3)->format('d-m-Y')); ?>

                                        </small>
                                    </div>

                                    <div class="form-group mt-3">
                                        <label>Bukti Kegiatan</label>
                                        <div id="imageUploadContainer-<?php echo e($item->id); ?>">
                                            <div class="input-group mb-2">
                                                <input type="file" name="images[]" class="form-control" accept="image/*">
                                            </div>
                                            <div class="input-group mb-2">
                                                <textarea name="desc[]" class="form-control" rows="3"></textarea>
                                            </div>
                                        </div>
                                        <button type="button" class="btn btn-sm btn-info" onclick="addUploadField(<?php echo e($item->id); ?>)">
                                            + Tambah Foto
                                        </button>
                                    </div>
    

                                </div> <!-- modal-body -->

                                <div class="modal-footer">
                                    <button type="submit" class="btn btn-primary">Simpan Perubahan</button>
                                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Tutup</button>
                                </div>
                            </div> <!-- modal-content -->
                        </form>
                    </div> <!-- modal-dialog -->
                </div> <!-- modal -->
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </div>
        </div>

        <?php $__currentLoopData = $daily; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <!-- Modal Desc daily -->
                <div class="modal fade" id="modalDeskripsi<?php echo e($item->id); ?>" tabindex="-1" role="dialog" aria-labelledby="modalEditDailyLabel<?php echo e($item->id); ?>" aria-hidden="true">
                    <div class="modal-dialog" role="document">
                            <div class="modal-content">
                            <div class="modal-header">
                                <h5 class="modal-title" id="modalEditDailyLabel<?php echo e($item->id); ?>">Deskripsi Kegiatan <?php echo e($item->kegiatan); ?> :</h5>
                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                    <span aria-hidden="true">&times;</span>
                                </button>
                            </div>
                            <div class="modal-body">
                                <div class="mb-3">
                                    <p><?php echo e($item->deskripsi); ?></p>
                                </div>
                            </div> <!-- modal-body -->
                            </div> <!-- modal-content -->
                        </form>
                    </div> <!-- modal-dialog -->
                </div> <!-- modal -->
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          <!-- Tambah -->
        <div class="modal fade" id="modalTambahDaily" tabindex="-1">
            <div class="modal-dialog">
                <form action="<?php echo e(route('daily.store')); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title">Tambah Kegiatan Harian</h5>
                            <button class="close" data-dismiss="modal">&times;</button>
                        </div>
                        <div class="modal-body">
                            <div class="mb-3">
                                <label>Nama Kegiatan</label>
                                <input type="text" name="kegiatan" class="form-control" required>
                            </div>
                            <div class="mb-3">
                                <label>Jenis Kegiatan</label>
                                <input type="text" name="jenis" class="form-control" required>
                            </div>
                            <div class="mb-3">
                                <label>Deskripsi</label>
                                <textarea name="deskripsi" class="form-control" rows="3"></textarea>
                            </div>
                        </div>
                        <div class="modal-footer">
                            <button  type="submit" class="btn btn-primary">Simpan</button>
                            <button class="btn btn-secondary" data-dismiss="modal">Tutup</button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
        <!-- Modal Konfirmasi Hapus -->
        <div class="modal fade" id="confirmDeleteModal" tabindex="-1" role="dialog" aria-labelledby="confirmDeleteModalLabel" aria-hidden="true">
            <div class="modal-dialog" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="confirmDeleteModalLabel">Konfirmasi Penghapusan</h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body">
                        Apakah Anda yakin ingin menghapus data ini? Proses ini tidak dapat dibatalkan.
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Batal</button>
                        <form id="deleteForm" action="" method="POST">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button type="submit" class="btn btn-danger">Hapus</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>

        <!-- Preview Gambar -->
        <div class="modal fade" id="imagePreviewModal" tabindex="-1" role="dialog" aria-hidden="true">
            <div class="modal-dialog modal-dialog-centered" role="document">
            <div class="modal-content">
                <div class="modal-body text-center">
                <img id="modalImagePreview" src="" class="img-fluid w-100 mb-3"
                    style="max-height: 80vh; object-fit: contain; border-bottom: 1px solid #dee2e6;" alt="Preview">
                <p id="modalImageDesc" class="text-muted small mb-0"></p>
                </div>
                <div class="modal-footer justify-content-center">
                <button type="button" class="btn btn-secondary btn-sm" data-dismiss="modal">Tutup</button>
                </div>
            </div>
            </div>
        </div>
  
        <!-- Modal Send Report -->
        <div class="modal fade" id="modalSendReport" tabindex="-1">
            <div class="modal-dialog">
                <form id="sendReportForm" action="<?php echo e(route('daily.massReport')); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <input type="hidden" name="ids" id="selectedDailyIds">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title">Konfirmasi Laporan</h5>
                            <button type="button" class="close" data-dismiss="modal">&times;</button>
                        </div>
                        <div class="modal-body">
                            <p>Apakah Anda yakin ingin melaporkan kegiatan yang dipilih?</p>
                        </div>
                        <div class="modal-footer">
                            <button type="submit" class="btn btn-primary">Ya, Laporkan</button>
                            <button class="btn btn-secondary" data-dismiss="modal">Batal</button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
<?php $__env->startPush('scripts'); ?>
<?php $__currentLoopData = $daily; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<script>
     function setDeleteAction(url) {
        // Mengubah action form ke URL yang sesuai
        document.getElementById('deleteForm').action = url;
    }

    // Inisialisasi modal ketika page load
    $(document).ready(function () {
        // Ketika modal ditutup, reset form action
        $('#confirmDeleteModal').on('hidden.bs.modal', function () {
            document.getElementById('deleteForm').action = '';
        });
    });
    
    let latestRequest = 0;

$('#filterStatus').on('change', function () {
    let status = $(this).val(); // Ambil nilai status yang dipilih
    latestRequest++;  // Increment counter
    const thisRequest = latestRequest;

    $.ajax({
        url: '<?php echo e(route("daily.index")); ?>',  // Route untuk index yang sudah ada
        type: 'GET',
        data: {
            status: status  // Kirimkan status ke controller
        },
        success: function (response) {
            if (thisRequest !== latestRequest) return;

            // Ambil isi baru dari response (table)
            let newDoc = document.createElement('html');
            newDoc.innerHTML = response;

            // Ambil tbody yang baru
            let newTbody = $(newDoc).find('#dataTable tbody').html();

            if ($.trim(newTbody) === '') {
                $('#dataTable tbody').html(`
                    <tr>
                        <td colspan="7" class="text-center">Tidak ada data ditemukan.</td>
                    </tr>
                `);
            } else {
                $('#dataTable tbody').html(newTbody);
            }
        },
        error: function (xhr) {
            console.log('Filter error', xhr.responseText);
        }
    });
});

function addUploadField(id) {
    const container = document.getElementById('imageUploadContainer-' + id);

    const inputGroupFile = document.createElement('div');
    inputGroupFile.classList.add('input-group', 'mb-2');

    const inputFile = document.createElement('input');
    inputFile.type = 'file';
    inputFile.name = 'images[]';
    inputFile.classList.add('form-control');
    inputFile.accept = 'image/*';

    inputGroupFile.appendChild(inputFile);

    const inputGroupDesc = document.createElement('div');
    inputGroupDesc.classList.add('input-group', 'mb-2');

    const inputDesc = document.createElement('textarea');
    inputDesc.name = 'desc[]';
    inputDesc.classList.add('form-control');
    inputDesc.rows = 3;

    inputGroupDesc.appendChild(inputDesc);

    // Tambahkan keduanya ke container
    container.appendChild(inputGroupFile);
    container.appendChild(inputGroupDesc);
}


document.addEventListener('DOMContentLoaded', function () {
    var tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
    var tooltipList = tooltipTriggerList.map(function (tooltipTriggerEl) {
        return new bootstrap.Tooltip(tooltipTriggerEl);
    });
});


document.addEventListener('DOMContentLoaded', function () {
    var tooltipTriggerList = [].slice.call(document.querySelectorAll('[title]'));
    tooltipTriggerList.map(function (el) {
        return new bootstrap.Tooltip(el);
    });
});

document.addEventListener('DOMContentLoaded', function () {
    const modal = new bootstrap.Modal(document.getElementById('imagePreviewModal'));
    const modalImg = document.getElementById('modalImagePreview');
    const modalDesc = document.getElementById('modalImageDesc');

    document.querySelectorAll('.preview-uploaded-img').forEach(img => {
        img.addEventListener('click', function () {
            const imgSrc = this.getAttribute('data-img');
            const desc = this.getAttribute('data-desc');
            modalImg.src = imgSrc;
            modalDesc.textContent = desc;
            modal.show();
        });
    });
});

$(document).ready(function() {
        $('#modalEditDaily<?php echo e($item->id); ?>').on('show.bs.modal', function (event) {
            console.log('Modal Edit akan muncul untuk ID ' + <?php echo e($item->id); ?>);
        });
    });

    document.addEventListener('DOMContentLoaded', function () {
    const checkboxes = document.querySelectorAll('.daily-checkbox');
    const sendReportBtn = document.getElementById('openMassReportModal');

    checkboxes.forEach(cb => {
        cb.addEventListener('change', function () {
            const anyChecked = Array.from(checkboxes).some(box => box.checked);
            sendReportBtn.disabled = !anyChecked;
        });
    });

    // Untuk "Ceklis Semua"
    document.getElementById('checkAllEligible').addEventListener('change', function () {
        const checked = this.checked;
        checkboxes.forEach(cb => {
            if (!cb.disabled) cb.checked = checked;
        });
        sendReportBtn.disabled = !Array.from(checkboxes).some(box => box.checked);
    });
});

document.addEventListener('DOMContentLoaded', function () {
    document.getElementById('openMassReportModal').addEventListener('click', function () {
        const checkedIds = Array.from(document.querySelectorAll('.daily-checkbox:checked')).map(cb => cb.value);
        document.getElementById('selectedDailyIds').value = checkedIds.join(',');
    });
});


// validasi untuk tanda send report bisa jadi loading spinner
document.addEventListener('DOMContentLoaded', function () {
    const allForms = document.querySelectorAll('form');

    allForms.forEach(form => {
        form.addEventListener('submit', function () {
            const submitBtn = form.querySelector('button[type="submit"]');

            if (submitBtn) {
                submitBtn.disabled = true;
                submitBtn.innerHTML = `
                    <span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span>
                    Sedang diproses...
                `;
            }
        });
    });
});
</script>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Laravel\ITP\ITP\resources\views/user/actv/index.blade.php ENDPATH**/ ?>