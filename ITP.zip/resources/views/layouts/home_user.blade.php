@extends('layouts.main')

@section('isi')
<div class="container-fluid mb-4">
    <div class="d-sm-flex align-items-center justify-content-between mb-4 ml-3">
        <h1 class="h3 mb-0 text-gray-800">You're Activity</h1>
    </div>
    <div class="row">
        <div class="col-xl-3 col-md-6 mb-4">
            <a href="{{ url('daily') }}" style="text-decoration: none;">
            <div class="card border-left-info shadow h-100 py-2">
                <div class="card-body">
                        <div class="row no-gutters align-items-center">
                            <div class="col mr-2">
                                <div class="text-xs font-weight-bold text-info text-uppercase mb-1">
                                You're Daily</div>
                                <div class="h5 mb-0 font-weight-bold text-gray-800">{{ $totalCount }}</div>
                            </div>
                            <div class="col-auto">
                                <i class="fas fa-clipboard-list fa-2x text-info"></i>
                            </div>
                        </div>
                    </div>
                </div>
            </a>
        </div>
    </div>
    <div class="row">
        <div class="col-xl-8 col-lg-7">
            <div class="card shadow-mb-4">
                <div class="card-header py-3">
                    <h6 class="m-0 font-weight-bold text primary">Bar Chart {{ $user->name }}</h6>
                </div>
                <div class="card-body">
                    <div class="row mb-4">
                        <div class="col-md-3">
                            <label for="filterType">Filter Tipe</label>
                            <select id="filterType" class="form-control">
                                <option value="daily">Harian</option>
                                <option value="weekly">Mingguan</option>
                                <option value="monthly">Bulanan</option>
                            </select>
                        </div>
                        <div class="col-md-3 filter-group" id="dailyInput">
                            <label for="filterDate">Pilih Tanggal</label>
                            <input type="date" id="filterDate" class="form-control">
                        </div>
                        <div class="col-md-6 filter-group d-none" id="weeklyInput">
                            <div class="row">
                                <div class="col-md-6">
                                    <label for="weekStart">Tanggal Mulai</label>
                                    <input type="date" id="weekStart" class="form-control">
                                </div>
                                <div class="col-md-6">
                                    <label for="weekEnd">Tanggal Akhir</label>
                                    <input type="date" id="weekEnd" class="form-control">
                                </div>
                            </div>
                        </div>
                        <div class="col-md-3 filter-group d-none" id="monthlyInput">
                            <label for="filterMonth">Pilih Bulan</label>
                            <input type="month" id="filterMonth" class="form-control">
                        </div>
                    </div>
                    <div class="chart-bar" style="position: relative; height: 500px; width: 100%;">
                        <canvas id="userBarChart"></canvas>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-xl-4 col-lg-5">
            <div class="card shadow mb-4">
                <div class="card-header py-3">
                    <h6 class="m-0 font-weight-bold text-primary">Info Daily</h6>
                </div>
                <div class="card-body">
                    <div class="mb-3">
                        <h5>Progress: <span id="progressCount">{{ $progressCount }}</span></h5>
                    </div>
                    <div class="mb-3">
                        <h5>dilaporkan: <span id="dilaporkanCount">{{ $dilaporkanCount }}</span></h5>
                    </div>
                    <div class="mb-3">
                        <h5>Diterima: <span id="diterimaCount">{{ $diterimaCount }}</span></h5>
                    </div>
                    <div class="mb-3">
                        <h5>Total : <span id="totalCount">{{ $totalCount }}</span></h5>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<script>
    // Ambil elemen filter
const filterTypeSelect = document.getElementById('filterType');
const filterDateInput = document.getElementById('filterDate');
const weeklyInput = document.getElementById('weeklyInput');
const monthlyInput = document.getElementById('monthlyInput');
const weekStartInput = document.getElementById('weekStart');
const weekEndInput = document.getElementById('weekEnd');
const filterMonthInput = document.getElementById('filterMonth');
const progressCountElement = document.getElementById('progressCount');
const dilaporkanCountElement = document.getElementById('dilaporkanCount');
const diterimaCountElement = document.getElementById('diterimaCount');
const totalCountElement = document.getElementById('totalCount');

// Chart Initialization
const ctx = document.getElementById('userBarChart').getContext('2d');
let userBarChart = new Chart(ctx, {
    type: 'bar',
    data: {
        labels: ['Total', 'Progress', 'Dilaporkan', 'Diterima'],
        datasets: [
            {
                label: 'Total',
                data: [{{ $totalCount }}, 0, 0, 0], // Total count (first bar)
                backgroundColor: '#3498db',
                borderWidth: 1
            },
            {
                label: 'Progress',
                data: [0, {{ $progressCount }}, 0, 0], // Progress count (second bar)
                backgroundColor: '#f1c40f',
                borderWidth: 1
            },
            {
                label: 'Dilaporkan',
                data: [0, 0, {{ $dilaporkanCount }}, 0], // Dilaporkan count (third bar)
                backgroundColor: '#e67e22',
                borderWidth: 1
            },
            {
                label: 'Diterima',
                data: [0, 0, 0, {{ $diterimaCount }}], // Diterima count (fourth bar)
                backgroundColor: '#2ecc71',
                borderWidth: 1
            }
        ]
    },
    options: {
        responsive: true,
        scales: {
            y: {
                beginAtZero: true,
                ticks: {
                    stepSize: 1
                }
            }
        }
    }
});


// Fungsi untuk memperbarui data chart
function fetchAndUpdateChart() {
    const type = filterTypeSelect.value;
    let url = `/filter-daily?type=${type}`;

    // Menentukan URL berdasarkan tipe filter yang dipilih (harian, mingguan, bulanan)
    if (type === 'daily') {
        const date = filterDateInput.value;
        if (!date) return; // Pastikan tanggal dipilih
        url += `&date=${date}`;
    } else if (type === 'weekly') {
        const start = weekStartInput.value;
        const end = weekEndInput.value;
        if (!start || !end) return; // Pastikan rentang tanggal lengkap
        url += `&start=${start}&end=${end}`;
    } else if (type === 'monthly') {
        const month = filterMonthInput.value;
        if (!month) return; // Pastikan bulan dipilih
        url += `&month=${month}`;
    }

    fetch(url)
    .then(res => res.json())
    .then(data => {
        console.log(data);  // Debugging response dari server
        
        // Memperbarui data chart dengan hasil dari API
        userBarChart.data.datasets[0].data = [data.total, 0, 0, 0]; // Total
        userBarChart.data.datasets[1].data = [0, data.progress, 0, 0]; // Progress
        userBarChart.data.datasets[2].data = [0, 0, data.dilaporkan, 0]; // Dilaporkan
        userBarChart.data.datasets[3].data = [0, 0, 0, data.diterima]; // Diterima

        // Memperbarui chart visual
        userBarChart.update();

        // Memperbarui count yang ditampilkan
        progressCountElement.innerText = data.progress;
        dilaporkanCountElement.innerText = data.dilaporkan;
        diterimaCountElement.innerText = data.diterima;
        totalCountElement.innerText = data.total;
    })
    .catch(error => {
        console.error("Error fetching data:", error);
    });
}

// Listener perubahan filter
filterTypeSelect.addEventListener('change', (e) => {
    const selectedType = e.target.value;
    
    // Sembunyikan semua filter input terlebih dahulu
    filterDateInput.closest('.filter-group').classList.add('d-none');
    weeklyInput.classList.add('d-none');
    monthlyInput.classList.add('d-none');

    // Tampilkan input yang sesuai dengan tipe yang dipilih
    if (selectedType === 'daily') {
        filterDateInput.closest('.filter-group').classList.remove('d-none');
    } else if (selectedType === 'weekly') {
        weeklyInput.classList.remove('d-none');
    } else if (selectedType === 'monthly') {
        monthlyInput.classList.remove('d-none');
    }

    fetchAndUpdateChart(); // Trigger chart update
});

// Trigger perubahan filter
document.querySelectorAll('input').forEach(input => {
    input.addEventListener('change', fetchAndUpdateChart);
});

filterTypeSelect.dispatchEvent(new Event('change'));  // Trigger initial filter input display

</script>
@endsection
