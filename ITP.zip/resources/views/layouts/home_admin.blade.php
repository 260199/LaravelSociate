@extends('layouts.main')

@section('isi')
<div class="container-fluid">
    <div class="d-sm-flex align-items-center justify-content-between mb-4">
        <h1 class="h3 mb-0 ">Admin Dashboard</h1>
    </div>
    <div class="row">
        <div class="col-xl-3 col-md-6 mb-4">
            <a href="actv" style="text-decoration:none;">
                <div class="card border-left-info shadow h-100 py-2">
                    <div class="card-body">
                        <div class="row no-gutters align-items-center">
                            <div class="col mr-2">
                                <div class="text-xs font-weight-bold text-info text-uppercase mb-1"> 
                                    Daily
                                </div>
                                <div class="h5 mb-0 font-weight-bold text-gray-800">
                                    {{ $allduty }}
                                </div>
                            </div>
                            <div class="col-auto">
                                <i class="fas fa-clipboard-list fa-2x text-info"></i>
                            </div>
                        </div>
                    </div>
                </div>
            </a>
        </div>
        <div class="col-xl-3 col-md-6 mb-4">
            <div class="card border-left-info shadow h-100 py-2">
                <div class="card-body">
                    <a href="users" style="text-decoration: none;">
                        <div class="row no-gutters align-items-center">
                            <div class="col mr-2">
                                <div class="text-xs font-weight-bold text-info text-uppercase mb-1">
                                     User
                                </div>
                                <div class="h5 mb-0 font-weight-bold text-gray-800">
                                    {{ $usercount }}
                                </div>
                            </div>
                            <div class="col-auto">
                                <i class="fas fa-user fa-2x text-info"></i>
                            </div>
                        </div>
                    </a>
                </div>
            </div>
        </div>
    </div>
    <div class="row">
        <!-- Chart Column -->
        <div class="col-xl-8 col-lg-7">
            <div class="card shadow mb-4">
                <div class="card-header py-3">
                    <h6 class="m-0 font-weight-bold text-primary">Bar Chart Daily</h6>
                </div>
                <div class="card-body">
                    <!-- Filter inside chart card -->
                    <div class="row mb-4">
                        <div class="col-md-3">
                            <label for="filterTypeAdmin">Filter Tipe</label>
                            <select id="filterTypeAdmin" class="form-control">
                                <option value="daily">Harian</option>
                                <option value="weekly">Mingguan</option>
                                <option value="monthly">Bulanan</option>
                            </select>
                        </div>
                        <!-- Harian -->
                        <div class="col-md-3 filter-group" id="dailyInputAdmin">
                            <label for="filterDateAdmin">Pilih Tanggal</label>
                            <input type="date" id="filterDateAdmin" class="form-control">
                        </div>
                        <!-- Mingguan -->
                        <div class="col-md-6 filter-group d-none" id="weeklyInputAdmin">
                            <div class="row">
                                <div class="col-md-6">
                                    <label for="weekStartAdmin">Tanggal Mulai</label>
                                    <input type="date" id="weekStartAdmin" class="form-control">
                                </div>
                                <div class="col-md-6">
                                    <label for="weekEndAdmin">Tanggal Akhir</label>
                                    <input type="date" id="weekEndAdmin" class="form-control">
                                </div>
                            </div>
                        </div>
                        <!-- Bulanan -->
                        <div class="col-md-3 filter-group d-none" id="monthlyInputAdmin">
                            <label for="filterMonthAdmin">Pilih Bulan</label>
                            <input type="month" id="filterMonthAdmin" class="form-control">
                        </div>
                    </div>
                    <!-- Chart -->
                    <div class="chart-bar" style="position: relative; height: 500px; width: 100%;">
                        <canvas id="adminBarChart"></canvas>
                    </div>
                </div>
            </div>
        </div>
        <!-- Info Boxes Column -->
        <div class="col-xl-4 col-lg-5">
            <div class="card shadow mb-4">
                <div class="card-header py-3">
                    <h6 class="m-0 font-weight-bold text-primary">Info Daily</h6>
                </div>
                <div class="card-body">
                    <div class="mb-3">
                        <h5>Total Users: <span id="totalUsers">{{ count($userStats) }}</span></h5>
                    </div>
                    <div class="mb-3">
                        <h5>Total Daily Progress: <span id="totalDailyProgress">{{ $totalProgress }}</span></h5>
                    </div>
                    <div class="mb-3">
                        <h5>Total Selesai: <span id="totalDiterima">{{ $totalDiterima }}</span></h5>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>


<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>

<script>
    const ctxAdmin = document.getElementById('adminBarChart').getContext('2d');

    const userStats = @json($userStats);

    let adminBarChart = new Chart(ctxAdmin, {
    type: 'bar',
    data: {
        labels: userStats.map(user => user.name),
        datasets: [
            {
                label: 'Progress',
                data: userStats.map(user => user.progress),
                backgroundColor: '#edb70e',
                borderWidth: 1
            },
            {
                label: 'Dilaporkan',
                data: userStats.map(user => user.dilaporkan),
                backgroundColor: '#3498db',
                borderWidth: 1
            },
            {
                label: 'Diterima',
                data: userStats.map(user => user.diterima),
                backgroundColor: '#2ecc71',
                borderWidth: 1
            }
        ]
    },

        options: {
            responsive: true,
            scales: {
                y: {
                    beginAtZero: true,
                    ticks: {
                        stepSize: 1
                    }
                }
            }
        }
    });

    // Filter 
    const filterTypeAdminSelect = document.getElementById('filterTypeAdmin');
    const filterDateAdminInput = document.getElementById('filterDateAdmin');
    const weekStartAdminInput = document.getElementById('weekStartAdmin');
    const weekEndAdminInput = document.getElementById('weekEndAdmin');
    const filterMonthAdminInput = document.getElementById('filterMonthAdmin');

    const dailyInputAdmin = document.getElementById('dailyInputAdmin');
    const weeklyInputAdmin = document.getElementById('weeklyInputAdmin');
    const monthlyInputAdmin = document.getElementById('monthlyInputAdmin');

    function toggleInputsAdmin(type) {
        dailyInputAdmin.classList.add('d-none');
        weeklyInputAdmin.classList.add('d-none');
        monthlyInputAdmin.classList.add('d-none');

        if (type === 'daily') {
            dailyInputAdmin.classList.remove('d-none');
        } else if (type === 'weekly') {
            weeklyInputAdmin.classList.remove('d-none');
        } else if (type === 'monthly') {
            monthlyInputAdmin.classList.remove('d-none');
        }
    }

    function fetchAndUpdateAdminChart() {
    const type = filterTypeAdminSelect.value;
    let url = `/filter-admin?type=${type}`;

    if (type === 'daily') {
        const date = filterDateAdminInput.value;
        if (!date) return;
        url += `&date=${date}`;
    } else if (type === 'weekly') {
        const start = weekStartAdminInput.value;
        const end = weekEndAdminInput.value;
        if (!start || !end) return;
        url += `&start=${start}&end=${end}`;
    } else if (type === 'monthly') {
        const month = filterMonthAdminInput.value;
        if (!month) return;
        url += `&month=${month}`;
    }

    fetch(url)
        .then(res => res.json())
        .then(response => {
            const data = response.userStats;

            if (!data || Object.keys(data).length === 0) {
                alert('Data tidak ditemukan');
                return;
            }

            // Update chart
            adminBarChart.data.labels = Object.keys(data);
            adminBarChart.data.datasets[0].data = Object.values(data).map(user => user.progress || 0);
            adminBarChart.data.datasets[1].data = Object.values(data).map(user => user.dilaporkan || 0);
            adminBarChart.data.datasets[2].data = Object.values(data).map(user => user.diterima || 0);
            adminBarChart.update();

            // Update Info Daily box
            document.getElementById('totalDailyProgress').textContent = response.totalProgress;
            document.getElementById('totalDiterima').textContent = response.totalDiterima;
            document.getElementById('totalUsers').textContent = response.totalUsers;
        })
        .catch(error => {
            console.error('Error fetching data:', error);
        });
}


    filterTypeAdminSelect.addEventListener('change', () => {
        const type = filterTypeAdminSelect.value;
        toggleInputsAdmin(type);
        fetchAndUpdateAdminChart();
    });

    filterDateAdminInput.addEventListener('change', fetchAndUpdateAdminChart);
    weekStartAdminInput.addEventListener('change', fetchAndUpdateAdminChart);
    weekEndAdminInput.addEventListener('change', fetchAndUpdateAdminChart);
    filterMonthAdminInput.addEventListener('change', fetchAndUpdateAdminChart);

    toggleInputsAdmin(filterTypeAdminSelect.value);
</script>
@endsection
