@extends('layouts.main')
@section('isi')
<div class="container-fluid">
    <div class="card shadow mb-4">
        <div class="card-header py-3">
            <h6 class="m-0 font-weight-bold text-primary">Log Activity</h6>
        </div>
        @if(session('success'))
            <div class="alert alert-success alert-dismissible fade show" role="alert">
                {{ session('success') }}
                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
        @endif


        <div class="card-body">
            <button class="btn btn-md btn-success mb-3" data-toggle="modal" data-target="#modalTambahDaily">
                Tambah Daily
            </button>
            <button class="btn btn-danger mb-3" id="openMassReportModal" data-toggle="modal" data-target="#modalSendReport" disabled>
                Send Report
            </button>

            <div class="form-check">
                <input class="form-check-input" type="checkbox" id="checkAllEligible">
                <label class="form-check-label" for="checkAllEligible">
                    Ceklis Semua yang Bisa Dilaporkan
                </label>
            </div>

            <div class="row mb-4">
                <div class="col-md-3">
                    <label for="filterUser">Pilih User</label>
                    <select id="filterUser" class="form-control">
                        <option value="">Semua User</option>
                        @foreach($users as $user)
                            <option value="{{ $user->id }}">{{ $user->name }}</option>
                        @endforeach
                    </select>
                </div>
            
                <div class="col-md-3">
                    <label for="filterStatus">Pilih Status</label>
                    <select id="filterStatus" class="form-control">
                        <option value="">Semua Status</option>
                        <option value="progress">Progress</option>
                        <option value="dilaporkan">Dilaporkan</option>
                        <option value="diterima">Diterima</option>
                    </select>
                </div>
            </div>
            <div class="table-responsive">
                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0" style="color:black;">
                    <thead>
                        <tr style="text-align: center;">
                            <th>#</th>
                            <th>Tgl Dibuat</th>
                            <th>Nama</th>
                            <th>Kegiatan</th>
                            <th>Jenis</th>
                            <th>Bukti</th>
                            <th>Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        @php
                            $no = 1;
                        @endphp
                        @foreach ($daily as $item)
                            @php
                                $buktiUploaded = $item->filedailies->count() > 0; // Cek apakah sudah ada bukti
                                $canCheck = $item->status === 'progress' && $buktiUploaded; // Cek ini hanya bisa dickelis kalo udah kelar upload bukti
                            @endphp
                            <tr>
                                <td>{{ $no++ }}
                                    <input type="checkbox" class="daily-checkbox" 
                                           value="{{ $item->id }}" 
                                           data-status="{{ $item->status }}" 
                                           data-owner-id="{{ $item->user_id }}" 
                                           {{ auth()->id() !== $item->user_id ? 'disabled' : '' }} 
                                           {{ !$canCheck ? 'disabled' : '' }}>
                                </td>
                                
                                <td>{{ \Carbon\Carbon::parse($item->created_at)->translatedFormat('d F Y') }}</td>
                                <td>{{ $item->user->name ?? 'N/A' }} <br>
                                    @if($item->status == 'diterima')
                                        <span class="badge badge-success">diterima</span>
                                    @elseif($item->status == 'dilaporkan')
                                        <span class="badge badge-danger">Waiting Approval</span>
                                    @else
                                        <span class="badge badge-warning">Sedang Proses</span>
                                    @endif
                                </td>
                                <td>{{ $item->kegiatan }}</td>
                                <td>{{ $item->jenis }}</td>
                                <td style="text-align: center;">
                                    @if($item->status == 'diterima')
                                        <a href="{{ route('actv.info', $item->id) }}" class="btn btn-sm btn-info" data-bs-toggle="tooltip" title="diterima pada: {{ \Carbon\Carbon::parse($item->done_at)->translatedFormat('d F Y') }}"><i class="fas fa-info"></i></a>
                                    @elseif($item->status == 'dilaporkan')
                                        <a href="{{ route('actv.info', $item->id) }}" class="btn btn-sm btn-primary" data-bs-toggle="tooltip" title="Dilaporkan pada: {{ \Carbon\Carbon::parse($item->done_at)->translatedFormat('d F Y') }}"><i class="fas fa-info"></i></a>
                                    @elseif($item->filedailies->count() > 0)
                                        <span class="badge badge-primary">Sudah upload kegiatan</span>
                                    @else
                                        -
                                    @endif
                                </td>
                                <td style="text-align: center;">
                                    <div class="d-flex align-items-center">
                                        @php
                                            $batasWaktu = \Carbon\Carbon::parse($item->created_at)->addDays(3);
                                        @endphp
                                        @if($item->status == 'progress' && now()->lessThanOrEqualTo($batasWaktu))
                                            <button class="btn btn-warning btn-sm" style="margin-left:5px;" data-toggle="modal" data-target="#modalEditDaily{{ $item->id }}" title="Edit">
                                                <i class="fas fa-edit"></i>
                                            </button>
                                        @endif
                                        @if($item->status == 'dilaporkan')
                                            <form id="approveForm_{{ $item->id }}" method="POST" action="{{ route('actv.approve', $item->id) }}">
                                                @csrf
                                                @method('POST')
                                                <button type="button" class="btn btn-success btn-sm" style="margin-left:5px;" title="Approve" data-toggle="modal" data-target="#approveModal" onclick="setApproveFormAction('{{ route('actv.approve', $item->id) }}')">
                                                    <i class="fas fa-check"></i> Approve
                                                </button>
                                            </form>
                                        @endif
                                        @if($item->status == 'diterima' || $item->status == 'dilaporkan')
                                            <button class="btn btn-warning btn-sm" style="margin-left:5px;" data-toggle="modal" data-target="#modalEditDaily{{ $item->id }}" title="Edit" disabled>
                                                <i class="fas fa-edit"></i>
                                            </button>
                                        @endif
                                        <form action="{{ route('actv.destroy', $item->id) }}" method="POST" class="d-inline-block" id="deleteForm{{ $item->id }}">
                                            @csrf @method('DELETE')
                                            <button type="button" class="btn btn-danger btn-sm" style="margin-left:5px;" title="Hapus" data-toggle="modal" data-target="#confirmDeleteModal" onclick="setDeleteAction('{{ route('actv.destroy', $item->id) }}')">
                                                <i class="fas fa-trash"></i>
                                            </button>
                                        </form>
                                        
                                        @if($item->status == 'progress' && now()->greaterThan($batasWaktu))
                                            <span class="badge badge-secondary ml-2">Expired</span>
                                        @endif
                                    </div>
                                </td>
                            </tr>
                        @endforeach
                    </tbody>
                </table>
            </div>
        </div>
        @foreach ($daily as $item)
                <!-- Modal Edit -->
                <div class="modal fade" id="modalEditDaily{{ $item->id }}" tabindex="-1" role="dialog" aria-labelledby="modalEditDailyLabel{{ $item->id }}" aria-hidden="true">
                    <div class="modal-dialog modal-dialog-scrollable modal-fullscreen-sm-down" role="document">
                        <form action="{{ route('actv.update', $item->id) }}" method="POST" enctype="multipart/form-data">
                            @csrf
                            @method('PUT')
                            <div class="modal-content">
                                <div class="modal-header">
                                    <h5 class="modal-title" id="modalEditDailyLabel{{ $item->id }}">Edit Kegiatan Harian</h5>
                                    <button type="button" class="close" data-dismiss="modal" aria-label="Tutup">
                                        <span aria-hidden="true">&times;</span>
                                    </button>
                                </div>
                                
                                <div class="modal-body">
                                    <div class="mb-3">
                                        <label for="kegiatan{{ $item->id }}">Nama Kegiatan</label>
                                        <input type="text" id="kegiatan{{ $item->id }}" name="kegiatan" class="form-control" value="{{ $item->kegiatan }}" required>
                                    </div>
                                    
                                    <div class="mb-3">
                                        <label for="jenis{{ $item->id }}">Jenis Kegiatan</label>
                                        <input type="text" id="jenis{{ $item->id }}" name="jenis" class="form-control" value="{{ $item->jenis }}" required>
                                    </div>
                                    
                                    <div class="mb-3">
                                        <label for="deskripsi{{ $item->id }}">Deskripsi</label>
                                        <textarea id="deskripsi{{ $item->id }}" name="deskripsi" class="form-control" rows="3">{{ $item->deskripsi }}</textarea>
                                    </div>

                                    @if($item->filedailies->count())
                                    <div class="mb-3">
                                        <label><strong>Bukti yang sudah diupload</strong></label><br>
                                        @foreach($item->filedailies as $file)
                                            <img
                                                src="{{ asset('storage/' . $file->image_path) }}"
                                                alt="Bukti"
                                                class="img-thumbnail preview-uploaded-img"
                                                data-img="{{ asset('storage/' . $file->image_path) }}"
                                                data-desc="{{ $file->desc ?: 'Tanpa deskripsi' }}"
                                                style="max-width: 100%; margin: 5px 0; border:1px solid #ddd; padding:3px; cursor: pointer;">
                                        @endforeach
                                    </div>
                                    @endif

                                    @php
                                        $doneAtValue = old('done_at') ?? ($item->done_at ? \Carbon\Carbon::parse($item->done_at)->format('Y-m-d') : '');
                                    @endphp

                                    <div class="form-group mt-3">
                                        <label for="done_at">Tanggal diterima</label>
                                        <input type="date" name="done_at" id="done_at" class="form-control"
                                            min="{{ $item->created_at->format('Y-m-d') }}"
                                            max="{{ $item->created_at->copy()->addDays(3)->format('Y-m-d') }}"
                                            value="{{ $doneAtValue }}"
                                            {{ $item->status === 'diterima' ? 'readonly' : '' }}>
                                        <small class="text-muted">
                                            Maksimal 3 hari dari tanggal dibuat: {{ $item->created_at->copy()->addDays(3)->format('d-m-Y') }}
                                        </small>
                                    </div>

                                    <div class="form-group mt-3">
                                        <label>Bukti Kegiatan</label>
                                        <div id="imageUploadContainer-{{ $item->id }}">
                                            <div class="input-group mb-2">
                                                <input type="file" name="images[]" class="form-control" accept="image/*">
                                            </div>
                                            <div class="input-group mb-2">
                                                <textarea name="desc[]" class="form-control" rows="3"></textarea>
                                            </div>
                                        </div>
                                        <button type="button" class="btn btn-sm btn-info" onclick="addUploadField({{ $item->id }})">
                                            + Tambah Foto
                                        </button>
                                    </div>
    

                                </div> <!-- modal-body -->

                                <div class="modal-footer">
                                    <button type="submit" class="btn btn-primary">Simpan Perubahan</button>
                                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Tutup</button>
                                </div>
                            </div> <!-- modal-content -->
                        </form>
                    </div> <!-- modal-dialog -->
                </div> <!-- modal -->
                @endforeach
          <!-- Tambah -->
        <div class="modal fade" id="modalTambahDaily" tabindex="-1">
            <div class="modal-dialog">
                <form action="{{ route('actv.store') }}" method="POST">
                    @csrf
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title">Tambah Kegiatan Harian</h5>
                            <button class="close" data-dismiss="modal">&times;</button>
                        </div>
                        <div class="modal-body">
                            <div class="mb-3">
                                <label>Nama Kegiatan</label>
                                <input type="text" name="kegiatan" class="form-control" required>
                            </div>
                            <div class="mb-3">
                                <label>Jenis Kegiatan</label>
                                <input type="text" name="jenis" class="form-control" required>
                            </div>
                            <div class="mb-3">
                                <label>Deskripsi</label>
                                <textarea name="deskripsi" class="form-control" rows="3"></textarea>
                            </div>
                        </div>
                        <div class="modal-footer">
                            <button  type="submit" class="btn btn-primary">Simpan</button>
                            <button class="btn btn-secondary" data-dismiss="modal">Tutup</button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
        <!-- Modal Approve -->
        <div class="modal fade" id="approveModal" tabindex="-1" role="dialog" aria-labelledby="approveModalLabel" aria-hidden="true">
            <div class="modal-dialog" role="document">
                <form id="approveForm" method="POST">
                    @csrf
                    @method('POST')
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title" id="approveModalLabel">Konfirmasi Approval</h5>
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                        <div class="modal-body">
                            <p>Apakah Anda yakin ingin menyetujui kegiatan ini?</p>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-dismiss="modal">Batal</button>
                            <button type="submit" class="btn btn-success">Ya, Setujui</button>
                        </div>
                    </div>
                </form>
            </div>
        </div>

        <!-- Modal Konfirmasi Hapus -->
        <div class="modal fade" id="confirmDeleteModal" tabindex="-1" role="dialog" aria-labelledby="confirmDeleteModalLabel" aria-hidden="true">
            <div class="modal-dialog" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="confirmDeleteModalLabel">Konfirmasi Penghapusan</h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body">
                        Apakah Anda yakin ingin menghapus data ini? Proses ini tidak dapat dibatalkan.
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Batal</button>
                        <form id="deleteForm" action="" method="POST">
                            @csrf
                            @method('DELETE')
                            <button type="submit" class="btn btn-danger">Hapus</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>

        <!-- Preview Gambar -->
        <div class="modal fade" id="imagePreviewModal" tabindex="-1" role="dialog" aria-hidden="true">
            <div class="modal-dialog modal-dialog-centered" role="document">
            <div class="modal-content">
                <div class="modal-body text-center">
                <img id="modalImagePreview" src="" class="img-fluid w-100 mb-3"
                    style="max-height: 80vh; object-fit: contain; border-bottom: 1px solid #dee2e6;" alt="Preview">
                <p id="modalImageDesc" class="text-muted small mb-0"></p>
                </div>
                <div class="modal-footer justify-content-center">
                <button type="button" class="btn btn-secondary btn-sm" data-dismiss="modal">Tutup</button>
                </div>
            </div>
            </div>
        </div>
  
        <!-- Modal Send Report -->
        <div class="modal fade" id="modalSendReport" tabindex="-1">
            <div class="modal-dialog">
                <form id="sendReportForm" action="{{ route('actv.massReports') }}" method="POST">
                    @csrf
                    <input type="hidden" name="ids" id="selectedDailyIds">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title">Konfirmasi Laporan</h5>
                            <button type="button" class="close" data-dismiss="modal">&times;</button>
                        </div>
                        <div class="modal-body">
                            <p>Apakah Anda yakin ingin melaporkan kegiatan yang dipilih?</p>
                        </div>
                        <div class="modal-footer">
                            <button type="submit" class="btn btn-primary">Ya, Laporkan</button>
                            <button class="btn btn-secondary" data-dismiss="modal">Batal</button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
@push('scripts')
@foreach ($daily as $item)
<script>
    function setApproveFormAction(url) {
    // Menetapkan action form modal sesuai dengan tombol yang diklik
    const approveForm = document.getElementById('approveForm');
    approveForm.action = url;
}

    function setDeleteAction(url) {
        // Mengubah action form ke URL yang sesuai
        document.getElementById('deleteForm').action = url;
    }

    // Inisialisasi modal ketika page load
    $(document).ready(function () {
        // Ketika modal ditutup, reset form action
        $('#confirmDeleteModal').on('hidden.bs.modal', function () {
            document.getElementById('deleteForm').action = '';
        });
    });
let latestRequest = 0;

$('#filterUser, #filterStatus').on('change', function () {
    let user_id = $('#filterUser').val();
    let status = $('#filterStatus').val();
    latestRequest++; // Tambah counter

    const thisRequest = latestRequest;

    $.ajax({
        url: '{{ route("actv.filter") }}',
        type: 'GET',
        data: {
            user_id: user_id,
            status: status
        },
        success: function (response) {
            if (thisRequest !== latestRequest) return;

            let newDoc = document.createElement('html');
            newDoc.innerHTML = response;

            let newTbody = $(newDoc).find('#dataTable tbody').html();

            if ($.trim(newTbody) === '') {
                $('#dataTable tbody').html(`
                    <tr>
                        <td colspan="7" class="text-center">Tidak ada data ditemukan.</td>
                    </tr>
                `);
            } else {
                $('#dataTable tbody').html(newTbody);
            }
        },
        error: function (xhr) {
            console.log('Filter error', xhr.responseText);
        }
    });
});

function addUploadField(id) {
    const container = document.getElementById('imageUploadContainer-' + id);

    const inputGroupFile = document.createElement('div');
    inputGroupFile.classList.add('input-group', 'mb-2');

    const inputFile = document.createElement('input');
    inputFile.type = 'file';
    inputFile.name = 'images[]';
    inputFile.classList.add('form-control');
    inputFile.accept = 'image/*';

    inputGroupFile.appendChild(inputFile);

    const inputGroupDesc = document.createElement('div');
    inputGroupDesc.classList.add('input-group', 'mb-2');

    const inputDesc = document.createElement('textarea');
    inputDesc.name = 'desc[]';
    inputDesc.classList.add('form-control');
    inputDesc.rows = 3;

    inputGroupDesc.appendChild(inputDesc);

    // Tambahkan keduanya ke container
    container.appendChild(inputGroupFile);
    container.appendChild(inputGroupDesc);
}


document.addEventListener('DOMContentLoaded', function () {
    var tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
    var tooltipList = tooltipTriggerList.map(function (tooltipTriggerEl) {
        return new bootstrap.Tooltip(tooltipTriggerEl);
    });
});


document.addEventListener('DOMContentLoaded', function () {
    var tooltipTriggerList = [].slice.call(document.querySelectorAll('[title]'));
    tooltipTriggerList.map(function (el) {
        return new bootstrap.Tooltip(el);
    });
});

document.addEventListener('DOMContentLoaded', function () {
    const modal = new bootstrap.Modal(document.getElementById('imagePreviewModal'));
    const modalImg = document.getElementById('modalImagePreview');
    const modalDesc = document.getElementById('modalImageDesc');

    document.querySelectorAll('.preview-uploaded-img').forEach(img => {
        img.addEventListener('click', function () {
            const imgSrc = this.getAttribute('data-img');
            const desc = this.getAttribute('data-desc');
            modalImg.src = imgSrc;
            modalDesc.textContent = desc;
            modal.show();
        });
    });
});

$(document).ready(function() {
        $('#modalEditDaily{{ $item->id }}').on('show.bs.modal', function (event) {
            console.log('Modal Edit akan muncul untuk ID ' + {{ $item->id }});
        });
    });

    document.addEventListener('DOMContentLoaded', function () {
    const adminId = {{ auth()->id() }}; // ID user yang sedang login (admin)
    const checkboxes = document.querySelectorAll('.daily-checkbox'); // Semua checkbox
    const sendReportForm = document.getElementById('sendReportForm'); // Form untuk laporan massal
    const sendReportBtn = document.getElementById('openMassReportModal'); // Tombol kirim laporan
    const selectAllCheckbox = document.getElementById('checkAllEligible'); // Checkbox "Ceklis Semua"

    // Fungsi untuk enable/disable tombol "Send Report" berdasarkan checkbox yang dicentang
    checkboxes.forEach(cb => {
        cb.addEventListener('change', function () {
            const anyChecked = Array.from(checkboxes).some(box => box.checked); // Cek apakah ada checkbox yang dicentang
            sendReportBtn.disabled = !anyChecked; // Disable tombol jika tidak ada yang dicentang
        });
    });

    // Untuk tombol "Ceklis Semua"
    selectAllCheckbox.addEventListener('change', function () {
        const checked = this.checked;
        checkboxes.forEach(cb => {
            // Pastikan hanya checkbox milik admin yang bisa dicentang
            if (cb.dataset.ownerId == adminId && !cb.disabled) {
                cb.checked = checked;
            }
        });
        // Aktifkan tombol jika ada checkbox yang dicentang
        sendReportBtn.disabled = !Array.from(checkboxes).some(box => box.checked);
    });

    // Sebelum form dikirim, pastikan ID yang dipilih sudah ada dalam input hidden
    sendReportForm.addEventListener('submit', function (e) {
        // Ambil semua ID dari checkbox yang dicentang
        const selectedIds = Array.from(checkboxes)
            .filter(cb => cb.checked)  // Filter checkbox yang dicentang
            .map(cb => cb.value);      // Ambil value (ID) dari checkbox yang dicentang

        // Log untuk debugging
        console.log("Selected IDs:", selectedIds);

        // Isi input hidden dengan ID yang dipilih
        document.getElementById('selectedDailyIds').value = selectedIds.join(',');

        // Jika tidak ada checkbox yang dicentang, hentikan submit form
        if (selectedIds.length === 0) {
            e.preventDefault(); // Mencegah form untuk disubmit
            alert('Harap pilih kegiatan yang ingin dilaporkan.');
        }
    });
});


// validasi untuk tanda send report bisa jadi loading spinner
document.addEventListener('DOMContentLoaded', function () {
    const allForms = document.querySelectorAll('form');

    allForms.forEach(form => {
        form.addEventListener('submit', function () {
            const submitBtn = form.querySelector('button[type="submit"]');

            if (submitBtn) {
                submitBtn.disabled = true;
                submitBtn.innerHTML = `
                    <span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span>
                    Sedang diproses...
                `;
            }
        });
    });
});

document.getElementById('myForm').addEventListener('submit', function(event) {
        var doneAt = document.getElementById('done_at').value;
        
        if (!doneAt) {
            event.preventDefault();
            alert('Tanggal Selesai wajib diisi!');
        }
    });
</script>
@endforeach
@endpush
@endsection